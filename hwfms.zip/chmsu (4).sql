-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2023 at 09:04 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chmsu`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `acc_id` int(11) NOT NULL,
  `acc_admin_id` text DEFAULT NULL,
  `acc_fname` text DEFAULT NULL,
  `acc_mname` text DEFAULT NULL,
  `acc_lname` text DEFAULT NULL,
  `acc_email` text DEFAULT NULL,
  `acc_phone` text DEFAULT NULL,
  `acc_birth` text DEFAULT NULL,
  `acc_address` text DEFAULT NULL,
  `acc_org` text DEFAULT NULL,
  `acc_uname` text DEFAULT NULL,
  `acc_password` text DEFAULT NULL,
  `acc_profile` text DEFAULT NULL,
  `acc_type` text DEFAULT NULL,
  `acc_status` text DEFAULT NULL,
  `acc_active` text DEFAULT NULL,
  `acc_check` text DEFAULT NULL,
  `acc_otp` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`acc_id`, `acc_admin_id`, `acc_fname`, `acc_mname`, `acc_lname`, `acc_email`, `acc_phone`, `acc_birth`, `acc_address`, `acc_org`, `acc_uname`, `acc_password`, `acc_profile`, `acc_type`, `acc_status`, `acc_active`, `acc_check`, `acc_otp`) VALUES
(8, '489757715', 'jer', 'super', 'admin', 'jerlendelosreyes7@gmail.com', '123456789', '2000-08-08', NULL, NULL, 'super_admin', '21232f297a57a5a743894a0e4a801fc3', 'default-profile.png', 'admin', NULL, NULL, NULL, '384731');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointment`
--

CREATE TABLE `tbl_appointment` (
  `id` int(11) NOT NULL,
  `appointment_rand_id` text DEFAULT NULL,
  `appointment_name` text DEFAULT NULL,
  `appointment_email` text DEFAULT NULL,
  `appointment_contact` text DEFAULT NULL,
  `appointment_address` text DEFAULT NULL,
  `appointment_date` text DEFAULT NULL,
  `appointment_time` text DEFAULT NULL,
  `appointment_message` text DEFAULT NULL,
  `appointment_title` text DEFAULT NULL,
  `appointment_type` text DEFAULT NULL,
  `appointment_status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brgy`
--

CREATE TABLE `tbl_brgy` (
  `brgy_id` int(11) NOT NULL,
  `brgy_name` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_brgy`
--

INSERT INTO `tbl_brgy` (`brgy_id`, `brgy_name`) VALUES
(4, 'Barangay 1'),
(5, 'Barangay 2'),
(6, 'Barangay 3'),
(7, 'Barangay 4'),
(8, 'Anahaw'),
(9, 'Aranda'),
(10, 'Baga-as'),
(11, 'Bato'),
(12, 'Calapi'),
(13, 'Camalobalo'),
(14, 'Camba-og'),
(15, 'Cambugsa'),
(16, 'Candumarao'),
(17, 'Gargato'),
(18, 'Himaya'),
(19, 'Miranda'),
(20, 'Nanunga'),
(21, 'Narauis'),
(22, 'Paticui'),
(23, 'Pilar'),
(24, 'Quiwi'),
(25, 'Tagda'),
(26, 'Tuguis'),
(27, 'Palayog');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_election_list`
--

CREATE TABLE `tbl_election_list` (
  `election_list_id` int(11) NOT NULL,
  `election_list_year` text DEFAULT NULL,
  `election_list_rand_id` text DEFAULT NULL,
  `election_list_name` text DEFAULT NULL,
  `election_list_brgy` text DEFAULT NULL,
  `election_list_position` text DEFAULT NULL,
  `election_list_org` text DEFAULT NULL,
  `election_list_status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_election_result`
--

CREATE TABLE `tbl_election_result` (
  `election_result_id` int(11) NOT NULL,
  `election_result_year` text DEFAULT NULL,
  `election_result_voter_id` text DEFAULT NULL,
  `election_result_candidates_id` text DEFAULT NULL,
  `election_result_address` text DEFAULT NULL,
  `election_result_position` text DEFAULT NULL,
  `election_result_org` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_organization`
--

CREATE TABLE `tbl_organization` (
  `org_id` int(11) NOT NULL,
  `org_name` text DEFAULT NULL,
  `org_brgy` text DEFAULT NULL,
  `org_create_date` text DEFAULT NULL,
  `org_status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_org_mem`
--

CREATE TABLE `tbl_org_mem` (
  `org_mem_id` int(11) NOT NULL,
  `org_mem_oname` text DEFAULT NULL,
  `org_mem_brgy` text DEFAULT NULL,
  `org_mem_name_id` text DEFAULT NULL,
  `org_mem_name` text DEFAULT NULL,
  `org_mem_pos` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pre_election`
--

CREATE TABLE `tbl_pre_election` (
  `pre_election_id` int(11) NOT NULL,
  `pre_election_year` text DEFAULT NULL,
  `pre_election_statrting` text DEFAULT NULL,
  `pre_election_end` text DEFAULT NULL,
  `pre_election_status` text DEFAULT NULL,
  `pre_election_type` text DEFAULT NULL,
  `pre_election_address` text DEFAULT NULL,
  `pre_election_period` text DEFAULT NULL,
  `pre_election_sysDef` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sched_events`
--

CREATE TABLE `tbl_sched_events` (
  `sched_events_id` int(11) NOT NULL,
  `sched_events_title` text DEFAULT NULL,
  `sched_events_date` text DEFAULT NULL,
  `sched_events_message` text DEFAULT NULL,
  `sched_events_type` text DEFAULT NULL,
  `sched_events_address` text DEFAULT NULL,
  `sched_events_org` text DEFAULT NULL,
  `sched_events_sponsor` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services`
--

CREATE TABLE `tbl_services` (
  `ser_id` int(11) NOT NULL,
  `ser_name` text DEFAULT NULL,
  `ser_rand_id_user` text DEFAULT NULL,
  `ser_user_name` text DEFAULT NULL,
  `ser_date` text DEFAULT NULL,
  `ser_type` text NOT NULL,
  `ser_address` text DEFAULT NULL,
  `ser_sponsor` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`acc_id`);

--
-- Indexes for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_brgy`
--
ALTER TABLE `tbl_brgy`
  ADD PRIMARY KEY (`brgy_id`);

--
-- Indexes for table `tbl_election_list`
--
ALTER TABLE `tbl_election_list`
  ADD PRIMARY KEY (`election_list_id`);

--
-- Indexes for table `tbl_election_result`
--
ALTER TABLE `tbl_election_result`
  ADD PRIMARY KEY (`election_result_id`);

--
-- Indexes for table `tbl_organization`
--
ALTER TABLE `tbl_organization`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `tbl_org_mem`
--
ALTER TABLE `tbl_org_mem`
  ADD PRIMARY KEY (`org_mem_id`);

--
-- Indexes for table `tbl_pre_election`
--
ALTER TABLE `tbl_pre_election`
  ADD PRIMARY KEY (`pre_election_id`);

--
-- Indexes for table `tbl_sched_events`
--
ALTER TABLE `tbl_sched_events`
  ADD PRIMARY KEY (`sched_events_id`);

--
-- Indexes for table `tbl_services`
--
ALTER TABLE `tbl_services`
  ADD PRIMARY KEY (`ser_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_brgy`
--
ALTER TABLE `tbl_brgy`
  MODIFY `brgy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_election_list`
--
ALTER TABLE `tbl_election_list`
  MODIFY `election_list_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_election_result`
--
ALTER TABLE `tbl_election_result`
  MODIFY `election_result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_organization`
--
ALTER TABLE `tbl_organization`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_org_mem`
--
ALTER TABLE `tbl_org_mem`
  MODIFY `org_mem_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_pre_election`
--
ALTER TABLE `tbl_pre_election`
  MODIFY `pre_election_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sched_events`
--
ALTER TABLE `tbl_sched_events`
  MODIFY `sched_events_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_services`
--
ALTER TABLE `tbl_services`
  MODIFY `ser_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
