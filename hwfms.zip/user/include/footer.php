<!-- Footer -->
<div class="row icon-div">

<div class="col-12 semi-grey p-4">
    <div class="row justify-content-center">

        <div class="col-xxl-1 col-xl-1 col-lg-1 col-2 text-white text-center">
            <a href="#">
               <p class="txt-footer text-white">
                  <i class="bi bi-twitter"></i>
               </p>
            </a>
        </div>

        <div class="col-xxl-1 col-xl-1 col-lg-1 col-2 text-white text-center">
            <a href="#">
               <p class="txt-footer text-white">
                  <i class="bi bi-instagram"></i>
               </p>
            </a>
        </div>

        <div class="col-xxl-1 col-xl-1 col-lg-1 col-2 text-white text-center">
            <a href="#">
               <p class="txt-footer text-white">
                  <i class="bi bi-facebook"></i>
               </p>
            </a>
        </div>

    </div>
</div>

<div class="col-12 dark-grey p-2">
    <div class="row justify-content-center">

        <div class="col-12 text-secodary text-center pt-xxl-3 pt-xl-3 pt-lg-3 pt-3">
             <p class="txt-footer-sub text-white">
             © 2023 HWFC Management System
             </p>
        </div>

    </div>
</div>

</div>
