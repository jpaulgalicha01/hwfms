<!-- SideNav -->
<script>
    $('.open-btn').on('click', function(){
        $('.sidebar').addClass('active');
    });


    $('.close-btn').on('click', function(){
        $('.sidebar').removeClass('active');
    });

    $('#close_modal_carou').on('click', function(){
        $('#modal_carou').modal('hide');
    })

</script>

<script>
</script>